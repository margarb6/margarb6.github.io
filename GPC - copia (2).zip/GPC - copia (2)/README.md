## Uso y alcance de este proyecto
### Este proyecto tiene exclusivamente fines docentes

El proyecto incluye material extraído del proyecto público [Three.js](http://threjs.org) *r140*, bibliotecas de utilidad del texto *"WebGL Programming Guide" de  Kouichi Matsuda y Rodger Lea* y código propio de *<rvivo@upv.es>*.  

Para más información sobre su uso y alcance consultar la [wiki](https://github.com/RobVivo/RobVivo.github.io/wiki/INSTRUCCIONES-B%C3%81SICAS)

Para comprobar el funcionamiento del navegador con WebGL
[cargue esta página](http://robvivo.github.io)
